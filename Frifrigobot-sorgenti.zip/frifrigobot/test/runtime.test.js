import { test } from "node:test";
import assert from "node:assert/strict";
import { Miniflare, convertV4MiniflareOptions } from "miniflare";
import { readFileSync } from "node:fs";
import { processUpdate, scheduled } from "../src/worker.js";
test("runtime workerd e D1 reali locali: schema, SQL, wizard e deduplica", async () => {
  const mf = new Miniflare(
    convertV4MiniflareOptions({
      modules: true,
      scriptPath: "build/worker.js",
      compatibilityDate: "2026-11-01",
      d1Databases: { DB: "test" },
      bindings: {
        WEBHOOK_SECRET: "local",
        CHAT_ID: "-55",
        ALLOWED_USER_IDS: "11",
        BOT_TOKEN: "fake",
      },
    }),
  );
  try {
    const DB = await mf.getD1Database("DB");
    const schema =
      readFileSync("migrations/0001_init.sql", "utf8") +
      readFileSync("migrations/0002_expiry_only.sql", "utf8");
    await DB.batch(
      schema
        .split(";")
        .map((s) => s.trim())
        .filter(Boolean)
        .map((s) => DB.prepare(s)),
    );
    assert.equal(
      (await mf.dispatchFetch("http://localhost/health")).status,
      200,
    );
    assert.equal(
      (
        await mf.dispatchFetch("http://localhost/telegram", {
          method: "POST",
          body: "{}",
        })
      ).status,
      403,
    );
    const sent = [];
    let message = 100,
      id = 0;
    const env = {
      DB,
      CHAT_ID: "-55",
      ALLOWED_USER_IDS: "11",
      BOT_TOKEN: "fake",
      FETCH: async (url, opts) => {
        sent.push(JSON.parse(opts.body));
        return Response.json({ ok: true, result: { message_id: ++message } });
      },
    };
    const cb = (data) =>
      processUpdate(env, {
        update_id: ++id,
        callback_query: {
          id: "x",
          data,
          from: { id: 11 },
          message: { message_id: 1, chat: { id: -55, type: "group" } },
        },
      });
    const text = async (value) => {
      const s = await DB.prepare("SELECT * FROM sessions WHERE user_id=?")
        .bind("11")
        .first();
      await processUpdate(env, {
        update_id: ++id,
        message: {
          message_id: 2,
          text: value,
          from: { id: 11 },
          chat: { id: -55, type: "group" },
          reply_to_message: { message_id: s.prompt_id },
        },
      });
    };
    const wiz = async (a) => {
      const s = await DB.prepare("SELECT * FROM sessions WHERE user_id=?")
        .bind("11")
        .first();
      await cb("wiz:" + s.token + ":" + a);
    };
    await cb("add");
    await text("Latte runtime");
    await text("3");
    await wiz("original");
    const token = (
      await DB.prepare("SELECT token FROM sessions WHERE user_id=?")
        .bind("11")
        .first()
    ).token;
    await Promise.all([
      cb("wiz:" + token + ":save"),
      cb("wiz:" + token + ":save"),
    ]);
    assert.equal(
      (await DB.prepare("SELECT count(*) n FROM products").first()).n,
      1,
    );
    let p = await DB.prepare("SELECT * FROM products").first();
    assert.equal(p.name, "Latte runtime");
    await cb(`open:${p.id}:1`);
    p = await DB.prepare("SELECT * FROM products").first();
    assert.ok(p.opened_date);
    assert.equal(p.version, 2);
    await cb(`finish:${p.id}:1`);
    assert.equal(
      (await DB.prepare("SELECT * FROM products").first()).finished,
      0,
    );
    await scheduled(env, new Date("2026-11-16T07:00:00Z"));
    assert.ok(sent.length > 0);
    const recovered = Array.from({ length: 100 }, (_, i) => ({
      id: "recovered" + i,
      name: "Prodotto " + i,
      category: "",
      original_date: null,
      after_days: 3,
      opened_date: null,
      quantity: "1 confezione",
      finished: 0,
    }));
    await DB.prepare(
      "INSERT INTO sessions(user_id,token,data,updated_at) VALUES(?,?,?,?)",
    )
      .bind(
        "11",
        "recovery-token",
        JSON.stringify({ step: "importconfirm", rows: recovered }),
        new Date().toISOString(),
      )
      .run();
    await cb("importconfirm:recovery-token");
    assert.equal(
      (await DB.prepare("SELECT count(*) n FROM products").first()).n,
      101,
    );
    await cb("importconfirm:recovery-token");
    assert.equal(
      (await DB.prepare("SELECT count(*) n FROM products").first()).n,
      101,
    );
  } finally {
    await mf.dispose();
  }
});
