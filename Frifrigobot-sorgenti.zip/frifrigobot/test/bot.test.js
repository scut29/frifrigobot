import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import worker, { processUpdate, scheduled, flush } from "../src/worker.js";
import {
  rome,
  addDays,
  parseDate,
  expiry,
  group,
  csv,
  readCSV,
} from "../src/domain.js";
class D1 {
  constructor(path = ":memory:") {
    this.db = new DatabaseSync(path);
  }
  prepare(sql) {
    const db = this.db;
    let params = [];
    const obj = {
      bind(...p) {
        params = p;
        return obj;
      },
      async first() {
        return db.prepare(sql).get(...params) || null;
      },
      async all() {
        return { results: db.prepare(sql).all(...params) };
      },
      async run() {
        const s = db.prepare(sql);
        const results = s.columns().length
          ? s.all(...params)
          : (s.run(...params), []);
        return {
          results,
          meta: { changes: db.prepare("SELECT changes() n").get().n },
        };
      },
    };
    return obj;
  }
  async batch(ss) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const out = [];
      for (const s of ss) out.push(await s.run());
      this.db.exec("COMMIT");
      return out;
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    }
  }
}
function setup(path) {
  const DB = new D1(path);
  DB.db.exec(
    readFileSync(
      new URL("../migrations/0001_init.sql", import.meta.url),
      "utf8",
    ),
  );
  DB.db.exec(
    readFileSync(
      new URL("../migrations/0002_expiry_only.sql", import.meta.url),
      "utf8",
    ),
  );
  DB.db.exec(
    readFileSync(
      new URL("../migrations/0003_compact_chat.sql", import.meta.url),
      "utf8",
    ),
  );
  const sent = [],
    api = [];
  let mid = 500;
  const env = {
    DB,
    CHAT_ID: "-10055",
    ALLOWED_USER_IDS: "11,22",
    BOT_TOKEN: "test",
    WEBHOOK_SECRET: "test-secret",
    FETCH: async (url, options) => {
      const method = url.split("/").pop(),
        body = options.body instanceof FormData ? {} : JSON.parse(options.body);
      api.push({ method, body });
      if (!["deleteMessage", "answerCallbackQuery"].includes(method))
        sent.push({ method, body });
      return Response.json({
        ok: true,
        result:
          method === "editMessageText"
            ? { message_id: body.message_id }
            : method === "sendMessage" || method === "sendDocument"
              ? { message_id: ++mid }
              : true,
      });
    },
  };
  let id = 0;
  const cb = (data, user = 11, chat = -10055, updateId) =>
    processUpdate(env, {
      update_id: updateId ? ((id = Math.max(id, updateId)), updateId) : ++id,
      callback_query: {
        id: "c" + id,
        from: { id: user },
        data,
        message: { message_id: 100, chat: { id: chat, type: "supergroup" } },
      },
    });
  const session = (user = 11) =>
    DB.db.prepare("SELECT * FROM sessions WHERE user_id=?").get(String(user));
  const text = (value, user = 11) =>
    processUpdate(env, {
      update_id: ++id,
      message: {
        message_id: 200 + id,
        from: { id: user },
        chat: { id: -10055, type: "supergroup" },
        text: value,
        reply_to_message: { message_id: session(user)?.prompt_id },
      },
    });
  const wiz = (action, user = 11) =>
    cb("wiz:" + session(user).token + ":" + action, user);
  return { env, DB, sent, api, cb, text, session, wiz };
}
async function add(h, name = "Latte", count = 1) {
  await h.cb("add");
  await h.text(name);
  const s = JSON.parse(h.session().data);
  if (s.after_days) await h.wiz("days:" + s.after_days);
  else await h.text("3");
  await h.wiz("original");
  if (count > 1) {
    await h.wiz("count");
    await h.text(String(count));
  }
  await h.wiz("save");
  return h.DB.db
    .prepare("SELECT * FROM products ORDER BY rowid DESC LIMIT 1")
    .get();
}
test("date italiane, anno bisestile e entrambi i cambi DST", () => {
  assert.deepEqual(rome(new Date("2026-01-01T07:00:00Z")), {
    date: "2026-01-01",
    hour: 8,
  });
  assert.equal(rome(new Date("2026-07-01T06:00:00Z")).hour, 8);
  assert.equal(rome(new Date("2026-03-29T06:00:00Z")).hour, 8);
  assert.equal(rome(new Date("2026-10-25T07:00:00Z")).hour, 8);
  assert.equal(addDays("2026-03-28", 3), "2026-03-31");
  assert.equal(parseDate("29/02/2026"), null);
  assert.equal(parseDate("29/02/2028"), "2028-02-29");
  assert.equal(parseDate("31/11/2026"), null);
});
test("scadenza minima e raggruppamento", () => {
  const p = {
    opened_date: "2026-11-16",
    after_days: 3,
    original_date: "2026-11-17",
  };
  assert.equal(expiry(p), "2026-11-17");
  assert.equal(group(p, "2026-11-18"), 0);
  assert.equal(group(p, "2026-11-17"), 1);
  assert.equal(expiry({ ...p, original_date: null }), "2026-11-19");
});
test("wizard, confezioni indipendenti, apertura, modifica, terminato e annullamento", async () => {
  const h = setup();
  let p = await add(h, "Latte", 2);
  assert.equal(h.DB.db.prepare("SELECT count(*) n FROM products").get().n, 2);
  await h.cb(`open:${p.id}:${p.version}`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.opened_date, rome().date);
  assert.equal(p.version, 2);
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM products WHERE opened_date IS NULL")
      .get().n,
    1,
  );
  await h.cb(`field:${p.id}:2:original_date`);
  await h.text("01/01/2026");
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(expiry(p), "2026-01-01");
  await h.cb(`finish:${p.id}:${p.version}`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.finished, 1);
  const last = h.sent.at(-1).body;
  await h.cb(last.reply_markup.inline_keyboard[0][0].callback_data);
  assert.equal(
    h.DB.db.prepare("SELECT finished FROM products WHERE id=?").get(p.id)
      .finished,
    0,
  );
  await h.cb("list:all:0", 22);
  assert.match(h.sent.at(-1).body.text, /Latte/);
});
test("durata ricordata e procedure separate per utente", async () => {
  const h = setup();
  await add(h);
  await h.cb("add");
  await h.text("latte");
  assert.match(h.sent.at(-1).body.text, /3 giorni/);
  const token = h.session().token;
  await h.cb("add", 22);
  await h.text("Yogurt", 22);
  assert.equal(h.session().token, token);
  assert.equal(JSON.parse(h.session(22).data).name, "Yogurt");
});
test("duplicati webhook e pulsanti superati", async () => {
  const h = setup();
  let p = await add(h);
  await h.cb(`open:${p.id}:1`, 11, -10055, 5000);
  await h.cb(`open:${p.id}:1`, 11, -10055, 5000);
  await h.cb(`finish:${p.id}:1`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.version, 2);
  assert.equal(p.finished, 0);
  assert.match(h.sent.at(-1).body.text, /superato/);
});
test("autorizzazioni gruppo, utenti e segreto webhook", async () => {
  const h = setup();
  await h.cb("add", 99);
  await h.cb("add", 11, -999);
  assert.equal(h.sent.length, 0);
  assert.equal(
    (
      await worker.fetch(
        new Request("https://bot/telegram", { method: "POST", body: "{}" }),
        h.env,
      )
    ).status,
    403,
  );
  assert.equal(
    (await worker.fetch(new Request("https://bot/health"), h.env)).status,
    200,
  );
});
test("notifica alle 8 italiane, deduplica e notifica prova", async () => {
  const h = setup();
  await add(h);
  h.DB.db.prepare("UPDATE products SET original_date=?").run("2026-11-17");
  h.sent.length = 0;
  await scheduled(h.env, new Date("2026-11-16T06:45:00Z"));
  assert.equal(h.sent.length, 0);
  await scheduled(h.env, new Date("2026-11-16T07:00:00Z"));
  assert.equal(h.sent.length, 1);
  await scheduled(h.env, new Date("2026-11-16T07:15:00Z"));
  assert.equal(h.sent.length, 1);
  await scheduled(h.env, new Date("2026-11-17T07:00:00Z"));
  assert.equal(h.sent.length, 2);
  await h.cb("testnotify");
  assert.match(h.sent.at(-1).body.text, /Notifica di prova/);
});
test("coda persistente e retry dopo errore Telegram", async () => {
  const h = setup(),
    original = h.env.FETCH;
  h.env.FETCH = async () =>
    Response.json(
      { ok: false, error_code: 429, parameters: { retry_after: 1 } },
      { status: 429 },
    );
  await h.cb("home");
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    1,
  );
  h.env.FETCH = original;
  await flush(h.env, Date.now() + 120000);
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    0,
  );
});
test("persistenza dopo chiusura e riapertura database su disco", async () => {
  const dir = mkdtempSync(join(tmpdir(), "frifrigobot-")),
    path = join(dir, "db.sqlite");
  const h = setup(path),
    p = await add(h);
  h.DB.db.close();
  const db = new D1(path);
  assert.equal(
    (
      await db
        .prepare("SELECT name FROM products WHERE id=?")
        .bind(p.id)
        .first()
    ).name,
    "Latte",
  );
  db.db.close();
  rmSync(dir, { recursive: true });
});
test("CSV completo: virgole, virgolette, righe multiple e validazione", () => {
  const p = {
    id: "abc",
    name: 'Latte, "bio"\nintero',
    category: "Latticini",
    original_date: null,
    after_days: 3,
    opened_date: null,
    quantity: "1",
    finished: 0,
  };
  assert.deepEqual(readCSV(csv([p]))[0], { ...p, track_opening: 1 });
  assert.throws(() => readCSV("evil\n1"));
  assert.throws(() => readCSV(csv([{ ...p, after_days: 0 }])));
});
test("rollback atomico D1 batch", async () => {
  const h = setup();
  await assert.rejects(() =>
    h.DB.batch([
      h.DB.prepare("UPDATE settings SET hour=10 WHERE id=1"),
      h.DB.prepare("INSERT INTO missing VALUES(1)"),
    ]),
  );
  assert.equal(h.DB.db.prepare("SELECT hour FROM settings").get().hour, 8);
});

test("attivazione protetta: origine, segreto, webhook e benvenuto unico", async () => {
  const h = setup();
  h.env.WEBHOOK_SECRET = "a".repeat(64);
  let target = null,
    welcome = 0;
  h.env.FETCH = async (url, opts) => {
    const method = url.split("/").pop(),
      body = JSON.parse(opts.body);
    let result = {};
    if (method === "getMe") result = { username: "Frifrigobot" };
    if (method === "getChat") result = { type: "supergroup" };
    if (method === "setWebhook") {
      target = body.url;
      result = true;
    }
    if (method === "getWebhookInfo") result = { url: target };
    if (method === "sendMessage") {
      welcome++;
      result = { message_id: 101 };
    }
    return Response.json({ ok: true, result });
  };
  const page = await worker.fetch(new Request("https://bot/setup"), h.env);
  assert.equal(page.status, 200);
  assert.equal(page.headers.get("Referrer-Policy"), "same-origin");
  assert.ok(!(await page.text()).includes(h.env.WEBHOOK_SECRET));
  const activate = (secret, origin = "https://bot") =>
    worker.fetch(
      new Request("https://bot/activate", {
        method: "POST",
        headers: {
          Origin: origin,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ secret }),
      }),
      h.env,
    );
  assert.equal((await activate("wrong")).status, 403);
  assert.equal(
    (await activate(h.env.WEBHOOK_SECRET, "https://elsewhere")).status,
    403,
  );
  assert.equal((await activate(h.env.WEBHOOK_SECRET)).status, 200);
  assert.equal(target, "https://bot/telegram");
  assert.equal(welcome, 1);
  await activate(h.env.WEBHOOK_SECRET);
  assert.equal(welcome, 1);
});

test("solo scadenza: creazione, memoria, divieto apertura e cambio modalità", async () => {
  const h = setup();
  await h.cb("add");
  await h.text("Uova");
  await h.wiz("noopening");
  await h.wiz("customoriginal");
  await h.text("26/11/2026");
  assert.doesNotMatch(
    JSON.stringify(h.sent.at(-1).body.reply_markup),
    /Salva e apri/,
  );
  await h.wiz("save");
  let p = h.DB.db.prepare("SELECT * FROM products").get();
  assert.equal(p.track_opening, 0);
  assert.equal(p.opened_date, null);
  await h.cb(`item:${p.id}`);
  let msg = h.sent.at(-1).body;
  assert.match(msg.text, /Solo scadenza/);
  assert.doesNotMatch(msg.text, /Dopo apertura|Aperto:|#[a-f0-9]/);
  assert.doesNotMatch(
    JSON.stringify(msg.reply_markup),
    /Apri oggi|Apertura precedente/,
  );
  await h.cb(`open:${p.id}:${p.version}`);
  assert.equal(
    h.DB.db.prepare("SELECT opened_date FROM products").get().opened_date,
    null,
  );
  await h.cb("list:closed:0");
  assert.match(h.sent.at(-1).body.text, /Nessun prodotto/);
  await h.cb("add");
  await h.text("Uova");
  assert.match(h.sent.at(-1).body.text, /Ricordo: solo scadenza/);
  await h.cb(`field:${p.id}:${p.version}:after_days`);
  await h.text("3");
  p = h.DB.db.prepare("SELECT * FROM products").get();
  assert.equal(p.track_opening, 1);
  await h.cb(`noopening:${p.id}:${p.version}`);
  assert.equal(
    h.DB.db.prepare("SELECT track_opening FROM products").get().track_opening,
    0,
  );
});

test("inventario per giorno, senza codici e confezioni distinte", async () => {
  const h = setup();
  const today = rome().date;
  for (const [i, n] of [-1, 0, 1, 2, 3, 10].entries())
    h.DB.db
      .prepare(
        "INSERT INTO products(id,name,original_date,after_days,track_opening,updated_at) VALUES(?,?,?,?,?,?)",
      )
      .run(
        "day" + i,
        "Alimento",
        addDays(today, n),
        1,
        0,
        new Date().toISOString(),
      );
  await h.cb("list:all:0");
  const msg = h.sent.at(-1).body;
  for (const label of [
    "Scaduti",
    "Da consumare oggi",
    "Entro domani",
    "Restano 2 giorni",
    "Restano 3 giorni",
    "Restano 10 giorni",
  ])
    assert.ok(msg.text.includes(label));
  assert.doesNotMatch(msg.text, /Entro 3 giorni|Chiusi|#day/);
  assert.match(msg.text, /confezione 1/);
  assert.match(msg.text, /confezione 6/);
  assert.equal(
    new Set(
      msg.reply_markup.inline_keyboard
        .slice(0, 6)
        .map((r) => r[0].callback_data),
    ).size,
    6,
  );
  await h.cb("list:due:0");
  assert.match(h.sent.at(-1).body.text, /Restano 10 giorni/);
});

test("CSV mantiene modalità e legge i backup precedenti", () => {
  const p = {
    id: "eggs",
    name: "Uova",
    category: "",
    original_date: "2026-11-26",
    after_days: 1,
    opened_date: null,
    quantity: "6 uova",
    finished: 0,
    track_opening: 0,
  };
  assert.deepEqual(readCSV(csv([p]))[0], p);
  const old =
    "id,name,category,original_date,after_days,opened_date,quantity,finished\nold,Latte,,2026-11-26,3,,1,0";
  assert.equal(readCSV(old)[0].track_opening, 1);
  assert.throws(() => readCSV(csv([{ ...p, opened_date: "2026-11-15" }])));
  assert.equal(expiry({ ...p, opened_date: "2026-11-15" }), "2026-11-26");
});

test("migrazione conserva i prodotti e corregge solo le uova segnalate", () => {
  const db = new DatabaseSync(":memory:");
  db.exec(
    readFileSync(
      new URL("../migrations/0001_init.sql", import.meta.url),
      "utf8",
    ),
  );
  for (const [id, name, days] of [
    ["a", "Uova", 365],
    ["b", "Latte", 365],
    ["c", "Uova", 3],
  ])
    db.prepare(
      "INSERT INTO products(id,name,after_days,original_date,updated_at) VALUES(?,?,?,?,?)",
    ).run(id, name, days, "2026-11-26", "old");
  db.exec(
    readFileSync(
      new URL("../migrations/0002_expiry_only.sql", import.meta.url),
      "utf8",
    ),
  );
  const ps = db.prepare("SELECT * FROM products ORDER BY id").all();
  assert.deepEqual(
    ps.map((p) => p.track_opening),
    [0, 1, 1],
  );
  assert.equal(ps[0].original_date, "2026-11-26");
  assert.equal(ps[0].version, 2);
  assert.equal(ps.length, 3);
  db.close();
});

test("menu e inventario usano lo stesso messaggio; notifiche restano", async () => {
  const h = setup();
  await h.cb("home");
  const panel = h.DB.db
    .prepare("SELECT * FROM ui_panels WHERE user_id=?")
    .get("11");
  await h.cb("list:all:0");
  await h.cb("settings");
  assert.equal(h.sent.filter((x) => x.method === "sendMessage").length, 1);
  assert.equal(h.sent.filter((x) => x.method === "editMessageText").length, 2);
  assert.equal(
    h.DB.db
      .prepare("SELECT message_id FROM ui_panels WHERE user_id=?")
      .get("11").message_id,
    panel.message_id,
  );
  await h.cb("testnotify");
  const alert = h.api.filter((x) => x.method === "sendMessage").at(-1);
  assert.match(alert.body.text, /Notifica di prova/);
  assert.equal(
    h.api.some(
      (x) =>
        x.method === "deleteMessage" && x.body.message_id === panel.message_id,
    ),
    false,
  );
});

test("domande e risposte vengono pulite solo dopo il nuovo messaggio", async () => {
  const h = setup();
  await h.cb("home");
  const old = h.DB.db
    .prepare("SELECT message_id FROM ui_panels")
    .get().message_id;
  await h.cb("add");
  const prompt = h.session().prompt_id;
  assert.ok(
    h.api.some(
      (x) => x.method === "deleteMessage" && x.body.message_id === old,
    ),
  );
  await h.text("PROVA Chat pulita");
  const last = h.DB.db
    .prepare("SELECT message_id FROM ui_panels")
    .get().message_id;
  assert.ok(
    h.api.some(
      (x) => x.method === "deleteMessage" && x.body.message_id === prompt,
    ),
  );
  assert.ok(
    h.api.some(
      (x) =>
        x.method === "deleteMessage" &&
        x.body.message_id > 200 &&
        x.body.message_id < 500,
    ),
  );
  assert.ok(
    !h.api.some(
      (x) => x.method === "deleteMessage" && x.body.message_id === last,
    ),
  );
  const firstDelete = h.api.findIndex((x) => x.method === "deleteMessage");
  assert.ok(
    h.api.slice(0, firstDelete).filter((x) => x.method === "sendMessage")
      .length === 2,
  );
});

test("le procedure contemporanee non cancellano il pannello altrui", async () => {
  const h = setup();
  await h.cb("add", 11);
  const a = h.session(11).prompt_id;
  await h.cb("add", 22);
  const b = h.session(22).prompt_id;
  assert.notEqual(a, b);
  await h.text("Latte", 11);
  assert.ok(
    !h.api.some((x) => x.method === "deleteMessage" && x.body.message_id === b),
  );
  assert.equal(h.session(22).prompt_id, b);
  await h.text("Yogurt", 22);
  assert.equal(JSON.parse(h.session(11).data).name, "Latte");
  assert.equal(JSON.parse(h.session(22).data).name, "Yogurt");
});

test("edit identico, pannello mancante e pulizia senza permessi non bloccano", async () => {
  const h = setup();
  await h.cb("home");
  const original = h.env.FETCH;
  let mode = "same";
  h.env.FETCH = async (url, opts) => {
    if (url.endsWith("/editMessageText"))
      return Response.json(
        {
          ok: false,
          error_code: 400,
          description:
            mode === "same"
              ? "Bad Request: message is not modified"
              : "Bad Request: message to edit not found",
        },
        { status: 400 },
      );
    if (url.endsWith("/deleteMessage"))
      return Response.json(
        { ok: false, error_code: 403, description: "Forbidden" },
        { status: 403 },
      );
    return original(url, opts);
  };
  const before = h.DB.db
    .prepare("SELECT message_id FROM ui_panels")
    .get().message_id;
  await h.cb("home");
  assert.equal(
    h.DB.db.prepare("SELECT message_id FROM ui_panels").get().message_id,
    before,
  );
  mode = "missing";
  await h.cb("list:all:0");
  assert.notEqual(
    h.DB.db.prepare("SELECT message_id FROM ui_panels").get().message_id,
    before,
  );
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    0,
  );
});

test("retry di invio non cancella domanda o risposta prima della consegna", async () => {
  const h = setup();
  await h.cb("add");
  const prompt = h.session().prompt_id,
    original = h.env.FETCH;
  let failing = true;
  h.env.FETCH = async (url, opts) =>
    failing && url.endsWith("/sendMessage")
      ? Response.json(
          { ok: false, error_code: 429, parameters: { retry_after: 1 } },
          { status: 429 },
        )
      : original(url, opts);
  await h.text("Riprova");
  assert.ok(
    !h.api.some(
      (x) => x.method === "deleteMessage" && x.body.message_id === prompt,
    ),
  );
  failing = false;
  await flush(h.env, Date.now() + 120000);
  assert.ok(
    h.api.some(
      (x) => x.method === "deleteMessage" && x.body.message_id === prompt,
    ),
  );
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    0,
  );
});

test("pulizia ritentata dopo errore transitorio e aggiornamenti vecchi ignorati", async () => {
  const h = setup();
  await h.cb("add");
  const original = h.env.FETCH;
  let failed = false;
  h.env.FETCH = async (url, opts) => {
    if (!failed && url.endsWith("/deleteMessage")) {
      failed = true;
      return Response.json(
        { ok: false, error_code: 429, parameters: { retry_after: 1 } },
        { status: 429 },
      );
    }
    return original(url, opts);
  };
  await h.text("Nome");
  assert.equal(h.DB.db.prepare("SELECT count(*) n FROM ui_cleanup").get().n, 1);
  await flush(h.env, Date.now() + 120000);
  assert.equal(h.DB.db.prepare("SELECT count(*) n FROM ui_cleanup").get().n, 0);
  await h.cb("home", 11, -10055, 900);
  const count = h.sent.length;
  await h.cb("settings", 11, -10055, 899);
  assert.equal(h.sent.length, count);
});
