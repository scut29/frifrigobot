# Frifrigobot

[![Deploy to Cloudflare](https://deploy.workers.cloudflare.com/button)](https://deploy.workers.cloudflare.com/?url=https%3A%2F%2Fgithub.com%2Fscut29%2Ffrifrigobot)

Bot Telegram domestico per due persone, con inventario condiviso e scadenze dopo l’apertura.
Bot registrato: https://t.me/Frifrigobot

## Stato della consegna

Il codice è sviluppato e verificato localmente. La pubblicazione nel tuo account Cloudflare e le prove sui telefoni richiedono ancora l’accesso al pannello e l’identificazione del gruppo. Nessun Worker o database remoto è stato dichiarato creato.

## Uso quotidiano

- All’avvio scrivi `/start` nel gruppo. Poi utilizza i pulsanti.
- **Aggiungi prodotto**: nome, giorni dopo apertura, scadenza facoltativa, conferma. Il bot ricorda i giorni per nome di prodotto. Categoria e numero di confezioni sono facoltativi. Le risposte scritte vanno inviate rispondendo al messaggio del bot, anche con privacy Telegram attiva.
- **Apri prodotto** oppure **Il mio frigo**: scegli una confezione e premi **Apri oggi**. Puoi indicare un’apertura precedente, mai futura.
- La scadenza è il minimo fra apertura + giorni di durata e data sulla confezione. Le date sono giorni di calendario in Italia: una confezione che scade oggi è segnalata da consumare entro oggi, e diventa scaduta il giorno dopo. Non vengono inventate ore di scadenza non presenti sull’etichetta.
- Per due confezioni scegli **Numero confezioni**. Saranno record separati, con aperture e modifiche indipendenti. Quantità è una descrizione modificabile, per esempio “500 ml”.
- **Modifica** corregge nome, categoria, scadenze, giorni, apertura e quantità. Un trattino rimuove una data o la categoria. Rimuovere l’apertura richiude la confezione.
- **Terminato** rimuove dall’inventario attivo. **Annulla operazione** ripristina lo stato precedente se nel frattempo non ci sono altre modifiche. **Prodotti terminati** consente di ripristinare le ultime confezioni.
- **Impostazioni**: avviso il giorno prima, il giorno della scadenza e riepilogo utile, attivi inizialmente. Un solo messaggio aggregato giornaliero alle 8 italiane; nessun messaggio quando non serve. Il riepilogo include anche prodotti scaduti e quelli entro tre giorni.
- **Esporta CSV** invia tutti i prodotti, anche terminati. **Recupera CSV** recupera al massimo 100 confezioni per file e 100 KB; conserva i dati presenti e ignora gli ID già esistenti. Un’esportazione più grande va suddivisa mantenendo l’intestazione in ogni parte. Per il ripristino completo del database usare anche le funzioni D1 di esportazione/ripristino.

## Collegare la compagna

Creare un gruppo Telegram privato con entrambi, aggiungere @Frifrigobot, far inviare `/start` nel gruppo a ciascuno dei due account. Raccogliere i due ID numerici e l’ID del gruppo per la configurazione iniziale. Il bot non deve essere amministratore e la modalità privacy può restare attiva. Nessun altro utente o gruppo può consultare o modificare i dati. In caso di conversione del gruppo in supergruppo l’ID cambia e va aggiornato nel segreto CHAT_ID.

## Architettura e sicurezza

JavaScript senza dipendenze in produzione; Cloudflare Worker con webhook ufficiale Telegram; D1 SQLite persistente; un Cron Trigger ogni 15 minuti. Il controllo del fuso Europe/Rome applica automaticamente l’ora legale. Il controllo delle 8 avviene al primo trigger utile e recupera eventuali ritardi nella stessa giornata.

Schema in `migrations/0001_init.sql`: products (una confezione per ID), templates, sessions, processed, settings, outbox e undo. Le modifiche e la coda messaggi vengono confermate in un unico batch transazionale D1. La ricevuta dell’update protegge dai duplicati; il controllo della versione impedisce modifiche con pulsanti vecchi; la validazione del token di sessione è effettuata dentro la transazione, anche per doppi tocchi contemporanei. Le procedure dei due utenti sono separate.

Il percorso /telegram accetta solo POST con l’header segreto di Telegram. Gruppo e utenti devono essere esplicitamente autorizzati. /health espone solo una stringa statica, nessun dato. Non sono presenti endpoint pubblici di inventario o esportazione; l’attivazione è protetta dal segreto. Nessun token è incluso nei sorgenti. I log non stampano credenziali né contenuto dei messaggi. Gli snapshot per annullare vengono conservati 30 giorni; le ricevute update 7 giorni; le sessioni vengono eliminate dopo un giorno (scadono dopo un’ora); i messaggi inviati nella coda vengono svuotati del contenuto e rimossi dopo 30 giorni. I prodotti restano fino a una gestione esplicita del database.

## Pubblicazione (per manutenzione tecnica)

L’agente gestisce queste operazioni quando il tuo accesso è disponibile.

1. Accedere all’account Cloudflare scegliendo esclusivamente Workers Free, senza carta o upgrade.
2. Installare Node 24 e usare `npm ci`. `npm test` esegue test di dominio, interazioni e runtime locale workerd/D1.
3. Autenticare Wrangler nel proprio account. Creare D1: `npx wrangler d1 create frifrigobot`; copiare il database_id nel wrangler.toml.
4. Applicare lo schema: `npx wrangler d1 migrations apply frifrigobot --remote`.
5. Caricare tramite il sistema Secrets di Cloudflare i quattro valori BOT_TOKEN, WEBHOOK_SECRET (casuale), CHAT_ID e ALLOWED_USER_IDS (due ID separati da virgola). Non includerli in Git o nell’archivio. `.dev.vars.example` contiene esclusivamente segnaposto.
6. Pubblicare `npm run deploy`. Il wrangler.toml include il trigger `*/15 * * * *`. L’URL workers.dev non richiede domini a pagamento. La propagazione iniziale dei Cron può richiedere alcuni minuti.
7. Dall’ambiente protetto con BOT_TOKEN e WEBHOOK_SECRET, eseguire `node scripts/register-webhook.mjs https://URL-WORKER.workers.dev`. Lo script verifica /health e registra webhook con max_connections=1. Non elimina i messaggi già in coda.
8. Verificare menu, aggiunta, apertura, due confezioni, modifica, terminato, annullamento, CSV e notifica reale nel gruppo. Poi eseguire una nuova pubblicazione e verificare persistenza e consultazione dall’altro telefono.

Per conoscere gli ID iniziali, `scripts/discover-group.py` legge soltanto i /start di gruppo prima che il webhook venga attivato; il token viene letto da ambiente o input nascosto.

## Costo e limiti

Configurazione prevista: Workers Free + D1 Free, nessun altro servizio. Documentazione ufficiale verificata il 16 novembre 2026:

- Workers: 100.000 richieste al giorno; 10 ms CPU per invocazione; fino a 5 Cron Trigger per account. Ne viene usato uno.
- D1: 5 milioni di righe lette al giorno, 100.000 scritte al giorno; 5 GB totali, 500 MB per singolo database Free. Query indicizzate e importazione set-based per restare sotto il limite di 50 query per invocazione.
- Al superamento delle quote Free il servizio può rifiutare le operazioni fino al ripristino della quota. Non abilitare Workers Paid, prove, add-on o altri servizi a pagamento.
- Nessuna garanzia contrattuale di disponibilità sui piani gratuiti. I limiti e le politiche future del fornitore possono cambiare. Il progetto non richiede manutenzione quotidiana; è prudente conservare esportazioni occasionali.

Fonti: https://developers.cloudflare.com/workers/platform/limits/ ; https://developers.cloudflare.com/d1/platform/pricing/ ; https://developers.cloudflare.com/d1/platform/limits/ ; https://core.telegram.org/bots/api

## Limiti dichiarati

Telegram non offre una chiave d’idempotenza per sendMessage. La coda persistente elimina i doppi invii ordinari e ritenta gli errori; in caso di invio accettato da Telegram seguito da perdita della risposta, un retry può generare un duplicato. Una garanzia assoluta di invio esattamente una volta non è possibile con questa API. Gli avvisi sono riepiloghi giornalieri aggregati, non messaggi separati per ogni confezione. Le notifiche inviate non vengono modificate retroattivamente quando cambia un prodotto; le consultazioni nuove leggono sempre D1.

## Pubblicazione dal browser personale

È predisposto il flusso ufficiale Deploy to Cloudflare da repository GitHub. Il package.json dichiara le descrizioni dei segreti e applica automaticamente le migrazioni D1 tramite il binding DB nel comando deploy. L’ID database nullo in wrangler.toml è un segnaposto per il provisioning automatico, non un database esistente. Il collegamento GitHub e la successiva autorizzazione Cloudflare vanno completati prima di considerare il bot online. Nessun link di deploy valido può essere generato finché il repository non esiste.

## Attivazione dal telefono

Dopo la pubblicazione apri `/setup` sull’URL del Worker e inserisci esclusivamente il WEBHOOK_SECRET scelto nel modulo Cloudflare. La pagina protetta dal segreto registra il webhook e accoda un unico messaggio iniziale nel gruppo. Non mostra inventario, ID o credenziali. La pagina GET è pubblica; l’azione POST richiede il segreto e rifiuta richieste provenienti da origini diverse.

## Correzione provisioning D1

Il deploy cerca o crea il database e risolve il suo UUID prima delle migrazioni tramite `scripts/deploy.mjs`. Non esegue query contro il segnaposto nullo. Il token build richiede Account → D1 → Edit. Il file temporaneo `.wrangler-resolved.toml` non viene pubblicato in Git.

## Versione 1.1.0

- Nessun codice tecnico nei messaggi, nei pulsanti e nelle notifiche. Le confezioni omonime sono indicate come confezione 1, confezione 2.
- All’aggiunta scegliere **Solo scadenza** oppure **Giorni dopo apertura**. La scelta viene ricordata. Nei dettagli **Modifica → Solo scadenza** converte un prodotto esistente; **Giorni dopo apertura** ripristina la gestione dell’apertura.
- Inventario e Scadenze mostrano sezioni separate per ciascun giorno rimanente, indipendentemente dall’apertura.
- La migrazione 0002 conserva i prodotti e corregge le uova inserite con la durata provvisoria di 365 giorni.
- CSV aggiornato con modalità di apertura; lettura dei vecchi CSV ancora supportata.
- 23 test automatici superati, inclusi migrazione, modalità senza apertura e raggruppamento giornaliero.

## Versione 1.2.0 — chat compatta

Menu e inventario vengono aggiornati nello stesso messaggio. Le domande e le risposte di una procedura vengono rimosse dopo la consegna del passo successivo. Ogni utente ha il proprio pannello, per non cancellare la domanda ancora in uso dell’altra persona. Solo le risposte dirette alle domande del bot e i comandi riconosciuti vengono ripuliti; conversazioni, notifiche e CSV restano visibili. Il bot necessita del permesso di eliminare messaggi per ripulire anche le risposte degli utenti. I vecchi messaggi anteriori all’aggiornamento non vengono cancellati in blocco.

Migrazione 0003: pannelli personali e coda persistente per ritentare le cancellazioni fallite. Gli alimenti non vengono modificati. Test: 29 superati, inclusi casi di risposta Telegram persa/rifiutata, pannello eliminato manualmente e procedure indipendenti. Pubblicazione e test reali ancora da completare.

## Versione 1.2.1 — migrazione del gruppo

Recupera il nuovo ID se il gruppo è stato convertito in supergruppo. Accetta esclusivamente un redirect confermato dalla Bot API per il gruppo già autorizzato; nomi e campi inoltrati da utenti non autorizzano altri gruppi. La relazione viene conservata in D1 ed è usata anche dal cron. Le confezioni non vengono toccate. Vecchi pannelli, procedure incomplete e cancellazioni riferite al vecchio gruppo vengono invalidati per evitare collisioni tra ID messaggio. 33 test automatici superati.

## Versione 1.2.2

Nell’inventario i giorni rimanenti compaiono solo nell’intestazione della sezione. Sotto gli alimenti rimane la data di apertura, quando presente. La scheda del singolo prodotto e gli avvisi conservano le indicazioni sulla scadenza. Controllo sintattico e test esistente dell’inventario per giorno superati.

## Versione 1.2.3

Una riga vuota separa il titolo della categoria dal primo alimento e ciascun prodotto dal successivo.

## Versione 1.2.4

I pulsanti dei prodotti e delle operazioni di apertura usano l’icona alimentare 🍽️ al posto dei lucchetti. Controllo sintattico superato.
