Versione 1.2.1: recupero ID dopo conversione in supergruppo; 33 test automatici superati. Pubblicazione e verifica reale del recupero in corso. Nessuna confezione modificata dalla migrazione.
