# Frifrigobot 1.2.0 — stato 18/11/2026

Sviluppata pulizia chat con pannello per utente, modifica sul posto, rimozione domande e risposte dopo consegna riuscita e coda retry. 29 test automatici superati (SQLite nativo e workerd/D1 locale).

Non pubblicato: GitHub connector risponde 403 in scrittura e la sessione browser precedente non è più autenticata. Occorre accesso sicuro GitHub; successivamente upload dei file in pubblicazione, attesa Workers Build e test reali Telegram. Nessun dato di inventario modificato.
