import { activation } from "./activation.js";
import {
  rome,
  parseDate,
  displayDate,
  expiry,
  group,
  expiryTitle,
  packageLabel,
  tracksOpening,
  sorted,
  remaining,
  csv,
  readCSV,
  daysBetween,
} from "./domain.js";
const btn = (text, callback_data) => ({ text, callback_data });
const keys = (inline_keyboard) => ({ inline_keyboard });
const home = () =>
  keys([
    [btn("🧊 Il mio frigo", "list:all:0"), btn("➕ Aggiungi prodotto", "add")],
    [
      btn("🔓 Apri prodotto", "list:closed:0"),
      btn("⏰ Scadenze", "list:due:0"),
    ],
    [btn("⚙️ Impostazioni", "settings")],
  ]);
const esc = (s) =>
  String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
const key = (s) => s.trim().normalize("NFKC").toLocaleLowerCase("it");
const uid = () => crypto.randomUUID().replaceAll("-", "").slice(0, 16);
const all = async (db, sql, ...p) =>
  (
    await db
      .prepare(sql)
      .bind(...p)
      .all()
  ).results;
const one = (db, sql, ...p) =>
  db
    .prepare(sql)
    .bind(...p)
    .first();
const fields = [
  "name",
  "category",
  "original_date",
  "after_days",
  "opened_date",
  "quantity",
  "finished",
  "track_opening",
];
class Plan {
  constructor(env, id, user) {
    this.env = env;
    this.id = id;
    this.user = String(user);
    this.statements = [];
    this.seq = 0;
    this.tag = `update:${id}`;
    this.owner = uid();
    this.expectedSession = null;
  }
  add(sql, ...params) {
    this.statements.push(
      this.env.DB.prepare(
        sql.replaceAll(
          "{G}",
          `EXISTS (SELECT 1 FROM processed WHERE id=${Number(this.id)} AND owner='${this.owner}' AND valid=1)`,
        ),
      ).bind(...params),
    );
  }
  send(text, markup = home(), extra = {}, condition = "1", args = []) {
    const payload = {
      method: "sendMessage",
      body: {
        chat_id: this.env.CHAT_ID,
        text,
        parse_mode: "HTML",
        reply_markup: markup,
        ...extra,
      },
    };
    this.add(
      `INSERT OR IGNORE INTO outbox(id,payload,created_at,session_token,user_id) SELECT ?,?,?,?,? WHERE {G} AND (${condition})`,
      `${this.tag}:${this.seq++}`,
      JSON.stringify(payload),
      new Date().toISOString(),
      extra._session || null,
      this.user,
      ...args,
    );
  }
  document(text) {
    this.add(
      "INSERT OR IGNORE INTO outbox(id,payload,created_at) SELECT ?,?,? WHERE {G}",
      `${this.tag}:${this.seq++}`,
      JSON.stringify({ method: "csv", text }),
      new Date().toISOString(),
    );
  }
  session(s) {
    const token = uid();
    this.add(
      "INSERT INTO sessions(user_id,token,data,updated_at) SELECT ?,?,?,? WHERE {G} ON CONFLICT(user_id) DO UPDATE SET token=excluded.token,data=excluded.data,prompt_id=NULL,updated_at=excluded.updated_at",
      this.user,
      token,
      JSON.stringify(s),
      new Date().toISOString(),
    );
    return token;
  }
  clear() {
    this.add("DELETE FROM sessions WHERE user_id=? AND {G}", this.user);
  }
  prompt(s, text) {
    const token = this.session(s);
    this.send(
      `<a href="tg://user?id=${this.user}">Per te</a> · ` +
        text +
        "\nRispondi a questo messaggio. Per annullare: /annulla",
      {
        force_reply: true,
        selective: true,
        input_field_placeholder: "Scrivi qui…",
      },
      {
        _session: token,
        ...(this.messageId
          ? { reply_parameters: { message_id: this.messageId } }
          : {}),
      },
    );
  }
  async commit() {
    const valid = this.expectedSession
      ? "EXISTS(SELECT 1 FROM sessions WHERE user_id=? AND token=?)"
      : "1";
    const params = [
      this.id,
      new Date().toISOString(),
      this.owner,
      ...(this.expectedSession ? [this.user, this.expectedSession] : []),
    ];
    const claim = this.env.DB.prepare(
      `INSERT OR IGNORE INTO processed(id,created_at,owner,valid) SELECT ?,?,?,${valid}`,
    ).bind(...params);
    const fallback = this.env.DB.prepare(
      "INSERT OR IGNORE INTO outbox(id,payload,created_at) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM processed WHERE id=? AND owner=? AND valid=0)",
    ).bind(
      this.tag + ":stale",
      JSON.stringify({
        method: "sendMessage",
        body: {
          chat_id: this.env.CHAT_ID,
          text: "Questa procedura è già stata completata o sostituita. Riapri il menu.",
          reply_markup: home(),
        },
      }),
      new Date().toISOString(),
      this.id,
      this.owner,
    );
    return this.env.DB.batch([claim, ...this.statements, fallback]);
  }
}
export async function telegram(env, method, body) {
  let response;
  try {
    response = await (env.FETCH || fetch)(
      `https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(12000),
      },
    );
  } catch {
    throw Error("Telegram non raggiungibile");
  }
  const data = await response.json();
  if (!data.ok) {
    const e = Error("Telegram API: " + response.status);
    e.code = data.error_code;
    e.retry = data.parameters?.retry_after;
    throw e;
  }
  return data.result;
}
export async function flush(env, now = Date.now()) {
  const rows = await all(
    env.DB,
    "SELECT * FROM outbox WHERE status='pending' AND lease_until<=? ORDER BY created_at,id LIMIT 4",
    now,
  );
  for (const r of rows) {
    const lease = await env.DB.prepare(
      "UPDATE outbox SET lease_until=?,attempts=attempts+1 WHERE id=? AND status='pending' AND lease_until<=?",
    )
      .bind(now + 60000, r.id, now)
      .run();
    if (!lease.meta.changes) continue;
    try {
      const p = JSON.parse(r.payload);
      let result;
      if (p.method === "csv") {
        const form = new FormData();
        form.set("chat_id", env.CHAT_ID);
        form.set(
          "document",
          new Blob([p.text], { type: "text/csv;charset=utf-8" }),
          "frifrigobot-inventario.csv",
        );
        const response = await (env.FETCH || fetch)(
          `https://api.telegram.org/bot${env.BOT_TOKEN}/sendDocument`,
          { method: "POST", body: form, signal: AbortSignal.timeout(12000) },
        );
        const d = await response.json();
        if (!d.ok) throw Error("Invio CSV fallito");
        result = d.result;
      } else {
        delete p.body._session;
        result = await telegram(env, p.method, p.body);
      }
      await env.DB.batch([
        env.DB.prepare(
          "UPDATE outbox SET status='sent',message_id=?,payload='{}' WHERE id=?",
        ).bind(result?.message_id || null, r.id),
        env.DB.prepare(
          "UPDATE sessions SET prompt_id=? WHERE user_id=? AND token=?",
        ).bind(result?.message_id || null, r.user_id, r.session_token),
      ]);
    } catch (e) {
      await env.DB.prepare("UPDATE outbox SET lease_until=? WHERE id=?")
        .bind(
          now +
            Math.min(
              3600000,
              Math.max(
                (e.retry || 0) * 1000,
                30000 * 2 ** Math.min(r.attempts, 6),
              ),
            ),
          r.id,
        )
        .run();
      console.error("outbox_delivery_failed", { code: e.code || 0 });
    }
  }
}
async function list(plan, mode = "all", page = 0) {
  const today = rome().date;
  let ps = sorted(
    await all(plan.env.DB, "SELECT * FROM products WHERE finished=0"),
    today,
  );
  if (mode === "closed")
    ps = ps.filter((p) => tracksOpening(p) && !p.opened_date);
  if (mode === "due") ps = ps.filter((p) => expiry(p));
  page = Math.max(
    0,
    Math.min(page, Math.max(0, Math.ceil(ps.length / 10) - 1)),
  );
  const chunk = ps.slice(page * 10, page * 10 + 10);
  let text =
    mode === "closed"
      ? "🔓 <b>Scegli una confezione da aprire</b>"
      : "🧊 <b>Il nostro frigo</b>";
  let prev = null;
  for (const p of chunk) {
    const g = expiryTitle(p, today);
    if (g !== prev) {
      text += `\n\n<b>${g}</b>`;
      prev = g;
    }
    text += `\n• <b>${esc(packageLabel(p, ps))}</b> · ${esc(p.quantity)}\n  ${remaining(p, today)}${p.opened_date ? " · aperto " + displayDate(p.opened_date) : ""}`;
  }
  if (!ps.length) text += "\nNessun prodotto in questa vista.";
  text +=
    "\n\nTocca una confezione per gestirla. Le date sono giorni italiani; “oggi” termina a mezzanotte.";
  const rows = chunk.map((p) => [
    btn(
      `${!tracksOpening(p) ? "📅" : p.opened_date ? "🔓" : "📦"} ${packageLabel(p, ps)}`,
      `item:${p.id}`,
    ),
  ]);
  const nav = [];
  if (page) nav.push(btn("←", `list:${mode}:${page - 1}`));
  if ((page + 1) * 10 < ps.length)
    nav.push(btn("→", `list:${mode}:${page + 1}`));
  if (nav.length) rows.push(nav);
  rows.push([btn("➕ Aggiungi", "add"), btn("🏠 Menu", "home")]);
  plan.send(text, keys(rows));
}
function card(plan, p) {
  const v = `${p.id}:${p.version}`,
    rows = [];
  if (!p.finished) {
    if (tracksOpening(p) && !p.opened_date)
      rows.push([
        btn("🔓 Apri oggi", `open:${v}`),
        btn("📅 Apertura precedente", `date:${v}`),
      ]);
    rows.push([
      btn("✅ Terminato", `finish:${v}`),
      btn("✏️ Modifica", `edit:${v}`),
    ]);
  } else rows.push([btn("↩️ Ripristina", `restore:${v}`)]);
  rows.push([btn("🧊 Inventario", "list:all:0")]);
  plan.send(
    `${p.finished ? "✅" : "📦"} <b>${esc(p.name)}</b>\n${esc(p.quantity)}${p.category ? " · " + esc(p.category) : ""}\nConfezione: ${displayDate(p.original_date)}${tracksOpening(p) ? `\nDopo apertura: ${p.after_days} giorni\nAperto: ${displayDate(p.opened_date)}` : "\n📅 Solo scadenza della confezione"}\nDa consumare entro: <b>${displayDate(expiry(p))}</b>\n${p.finished ? "Terminato" : remaining(p, rome().date)}`,
    keys(rows),
  );
}
async function change(plan, p, patch) {
  const next = { ...p, ...patch, version: p.version + 1 },
    undoId = uid();
  plan.add(
    "INSERT INTO undo(id,product_id,expected_version,snapshot,created_at) SELECT ?,?,?,?,? WHERE {G} AND EXISTS(SELECT 1 FROM products WHERE id=? AND version=?)",
    undoId,
    p.id,
    next.version,
    JSON.stringify(p),
    new Date().toISOString(),
    p.id,
    p.version,
  );
  plan.add(
    `UPDATE products SET ${fields.map((k) => k + "=?").join(",")},version=version+1,updated_at=?,last_event=? WHERE id=? AND version=? AND {G}`,
    ...fields.map((k) => (k === "track_opening" ? (next[k] ?? 1) : next[k])),
    new Date().toISOString(),
    plan.tag,
    p.id,
    p.version,
  );
  plan.send(
    `✅ <b>${esc(p.name)}</b> aggiornato.\n${next.finished ? "Confezione terminata." : remaining(next, rome().date) + " · scadenza " + displayDate(expiry(next))}`,
    keys([
      [btn("↩️ Annulla operazione", `undo:${undoId}`)],
      [btn("📦 Dettagli", `item:${p.id}`), btn("🧊 Inventario", "list:all:0")],
    ]),
    {},
    "EXISTS(SELECT 1 FROM products WHERE id=? AND last_event=?)",
    [p.id, plan.tag],
  );
  plan.send(
    "La confezione è stata modificata nel frattempo. Riapri i dettagli.",
    keys([[btn("Aggiorna", `item:${p.id}`)]]),
    {},
    "NOT EXISTS(SELECT 1 FROM products WHERE id=? AND last_event=?)",
    [p.id, plan.tag],
  );
}
async function askDays(plan, d) {
  const t = await one(
    plan.env.DB,
    "SELECT * FROM templates WHERE name_key=?",
    key(d.name),
  );
  const token = plan.session({
    ...d,
    category: t?.category || d.category || "",
    step: "days",
  });
  const rows = [];
  if (t && tracksOpening(t))
    rows.push([
      btn(`Usa ${t.after_days} giorni`, `wiz:${token}:days:${t.after_days}`),
    ]);
  rows.push([btn("📅 Solo scadenza", `wiz:${token}:noopening`)]);
  rows.push([btn("🔓 Giorni dopo apertura", `wiz:${token}:customdays`)]);
  rows.push([btn("Annulla", `cancel:${token}`)]);
  plan.send(
    `<b>${esc(d.name)}</b>\n${t ? (tracksOpening(t) ? `Ricordo: <b>${t.after_days} giorni dall’apertura</b>.\n` : "Ricordo: solo scadenza della confezione.\n") : ""}Come vuoi gestire la scadenza?\nPer uova e prodotti senza apertura scegli <b>Solo scadenza</b>.`,
    keys(rows),
  );
}
function askOriginal(plan, d) {
  const token = plan.session({ ...d, step: "original" });
  plan.send(
    "📅 Scadenza sulla confezione?",
    keys([
      [
        btn("Nessuna / non ora", `wiz:${token}:original`),
        btn("Inserisci data", `wiz:${token}:customoriginal`),
      ],
      [btn("Annulla", `cancel:${token}`)],
    ]),
  );
}
function review(plan, d) {
  const token = plan.session({ ...d, step: "review", count: d.count || 1 });
  plan.send(
    `📦 <b>${esc(d.name)}</b>\n${d.count || 1} confezioni separate\n${tracksOpening(d) ? `Dopo apertura: ${d.after_days} giorni` : "📅 Solo scadenza della confezione"}\nScadenza confezione: ${displayDate(d.original_date)}${d.category ? "\nCategoria: " + esc(d.category) : ""}${tracksOpening(d) ? "\nLe confezioni vengono aggiunte chiuse." : ""}`,
    keys([
      [
        btn("✅ Salva", `wiz:${token}:save`),
        ...(tracksOpening(d)
          ? [btn("🔓 Salva e apri oggi", `wiz:${token}:saveopen`)]
          : []),
      ],
      [
        btn("📦 Numero confezioni", `wiz:${token}:count`),
        btn("🏷 Categoria", `wiz:${token}:category`),
      ],
      [btn("Annulla", `cancel:${token}`)],
    ]),
  );
}
async function settings(plan) {
  const s = await one(plan.env.DB, "SELECT * FROM settings WHERE id=1");
  plan.send(
    `⚙️ <b>Impostazioni</b>\nAvvisi alle ${String(s.hour).padStart(2, "0")}:00, fuso Europe/Rome. Ora legale automatica.\nLe durate seguono l’etichetta; non verificano lo stato dell’alimento.`,
    keys([
      [btn(`${s.day_before ? "✅" : "⬜"} Giorno prima`, "toggle:day_before")],
      [btn(`${s.on_day ? "✅" : "⬜"} Giorno della scadenza`, "toggle:on_day")],
      [btn(`${s.summary ? "✅" : "⬜"} Riepilogo utile`, "toggle:summary")],
      [btn("🕗 Cambia ora", "hour"), btn("🔔 Prova notifica", "testnotify")],
      [btn("📤 Esporta CSV", "export"), btn("📥 Recupera CSV", "import")],
      [btn("📚 Prodotti terminati", "history"), btn("🏠 Menu", "home")],
    ]),
  );
}
async function handleText(plan, m, session) {
  const text = m.text?.trim() || "",
    command = text.split("@")[0];
  if (["/start", "/menu", "/frigo"].includes(command)) {
    plan.clear();
    plan.send(
      "🧊 <b>Frifrigobot</b>\nIl frigo condiviso, una confezione alla volta.",
    );
    return;
  }
  if (command === "/annulla") {
    plan.clear();
    plan.send("Operazione annullata.");
    return;
  }
  if (!session || m.reply_to_message?.message_id !== session.prompt_id) return;
  plan.expectedSession = session.token;
  const s = JSON.parse(session.data);
  if (Date.now() - Date.parse(session.updated_at) > 3600000) {
    plan.clear();
    plan.send("Procedura scaduta. Ricomincia dal menu.");
    return;
  }
  if (s.step === "import") {
    if (!m.document) {
      plan.prompt(s, "Allega il CSV esportato rispondendo a questo messaggio.");
      return;
    }
    if (m.document.file_size > 100000) {
      plan.send("File troppo grande: massimo 100 KB.");
      return;
    }
    const file = await telegram(plan.env, "getFile", {
      file_id: m.document.file_id,
    });
    const response = await (plan.env.FETCH || fetch)(
      `https://api.telegram.org/file/bot${plan.env.BOT_TOKEN}/${file.file_path}`,
      { signal: AbortSignal.timeout(12000) },
    );
    if (!response.ok) throw Error("CSV non disponibile");
    const raw = await response.text();
    if (new TextEncoder().encode(raw).length > 100000)
      throw Error("CSV troppo grande");
    try {
      const rows = readCSV(raw),
        token = plan.session({ step: "importconfirm", rows });
      plan.send(
        `📥 ${rows.length} confezioni da recuperare.\nGli ID già presenti saranno ignorati.`,
        keys([
          [btn("Conferma recupero", `importconfirm:${token}`)],
          [btn("Annulla", `cancel:${token}`)],
        ]),
      );
    } catch (e) {
      plan.send(esc(e.message));
    }
    return;
  }
  if (s.step === "name") {
    if (!text || text.length > 80) {
      plan.prompt(s, "Nome da 1 a 80 caratteri.");
      return;
    }
    await askDays(plan, { name: text, category: "", original_date: null });
    return;
  }
  if (s.step === "days") {
    if (!/^\d+$/.test(text) || +text < 1 || +text > 365) {
      plan.prompt(s, "Inserisci un numero intero da 1 a 365.");
      return;
    }
    askOriginal(plan, { ...s, after_days: +text, track_opening: 1 });
    return;
  }
  if (s.step === "original") {
    const d = parseDate(text);
    if (!d) {
      plan.prompt(
        s,
        "Data non valida. Usa GG/MM/AAAA, per esempio 25/11/2026.",
      );
      return;
    }
    review(plan, { ...s, original_date: d });
    return;
  }
  if (s.step === "count") {
    if (!/^\d+$/.test(text) || +text < 1 || +text > 20) {
      plan.prompt(s, "Da 1 a 20 confezioni per aggiunta.");
      return;
    }
    review(plan, { ...s, count: +text });
    return;
  }
  if (s.step === "category") {
    if (text.length > 60) {
      plan.prompt(s, "Categoria: massimo 60 caratteri.");
      return;
    }
    review(plan, { ...s, category: text === "-" ? "" : text });
    return;
  }
  if (s.step === "hour") {
    if (!/^\d{1,2}$/.test(text) || +text > 23) {
      plan.prompt(s, "Scrivi un’ora da 0 a 23.");
      return;
    }
    plan.add("UPDATE settings SET hour=? WHERE id=1 AND {G}", +text);
    plan.clear();
    plan.send(`✅ Avvisi alle ${text.padStart(2, "0")}:00 italiane.`);
    return;
  }
  if (s.step === "editfield") {
    const p = await one(plan.env.DB, "SELECT * FROM products WHERE id=?", s.id);
    if (!p || p.version !== s.version) {
      plan.clear();
      plan.send("La confezione è cambiata. Riapri i dettagli.");
      return;
    }
    let value = text;
    if (["opened_date", "original_date"].includes(s.field)) {
      value = text === "-" ? null : parseDate(text);
      if (text !== "-" && !value) {
        plan.prompt(
          s,
          "Data non valida: usa GG/MM/AAAA oppure - per rimuoverla.",
        );
        return;
      }
      if (s.field === "opened_date" && value > rome().date) {
        plan.prompt(s, "L’apertura non può essere nel futuro.");
        return;
      }
    } else if (s.field === "after_days") {
      if (!/^\d+$/.test(text) || +text < 1 || +text > 365) {
        plan.prompt(s, "Numero di giorni da 1 a 365.");
        return;
      }
      value = +text;
    } else {
      const limit = s.field === "name" ? 80 : 60;
      if (!value || value.length > limit) {
        plan.prompt(s, `Scrivi da 1 a ${limit} caratteri.`);
        return;
      }
      if (s.field === "category" && value === "-") value = "";
    }
    plan.clear();
    await change(plan, p, {
      [s.field]: value,
      ...(s.field === "after_days" ? { track_opening: 1 } : {}),
    });
    return;
  }
}
async function callback(plan, data, session) {
  const [op, a, b, c] = data.split(":"),
    s = session ? JSON.parse(session.data) : null;
  if (op === "home") {
    plan.send("🧊 <b>Frifrigobot</b>");
    return;
  }
  if (op === "list") {
    await list(plan, a, +b || 0);
    return;
  }
  if (op === "cancel") {
    if (session?.token === a) plan.clear();
    plan.send("Operazione annullata.");
    return;
  }
  if (op === "add") {
    plan.prompt({ step: "name" }, "➕ Come si chiama il prodotto?");
    return;
  }
  if (op === "item") {
    const p = await one(plan.env.DB, "SELECT * FROM products WHERE id=?", a);
    if (p) card(plan, p);
    else plan.send("Confezione non trovata.");
    return;
  }
  if (op === "settings") {
    await settings(plan);
    return;
  }
  if (op === "toggle" && ["day_before", "on_day", "summary"].includes(a)) {
    plan.add(`UPDATE settings SET ${a}=1-${a} WHERE id=1 AND {G}`);
    plan.send(
      "✅ Preferenza aggiornata.",
      keys([[btn("⚙️ Mostra impostazioni", "settings")]]),
    );
    return;
  }
  if (op === "hour") {
    plan.prompt(
      { step: "hour" },
      "A quale ora italiana vuoi gli avvisi? Scrivi un numero da 0 a 23.",
    );
    return;
  }
  if (op === "testnotify") {
    plan.send(
      "🔔 Notifica di prova di Frifrigobot.\nIl bot può inviare messaggi in questo gruppo.",
    );
    return;
  }
  if (op === "history") {
    const ps = await all(
      plan.env.DB,
      "SELECT * FROM products WHERE finished=1 ORDER BY updated_at DESC LIMIT 15",
    );
    plan.send(
      "📚 Ultime 15 confezioni terminate",
      keys([
        ...ps.map((p) => [btn(packageLabel(p, ps), `item:${p.id}`)]),
        [btn("🏠 Menu", "home")],
      ]),
    );
    return;
  }
  if (op === "export") {
    plan.document(
      csv(await all(plan.env.DB, "SELECT * FROM products ORDER BY id")),
    );
    plan.send(
      "📤 CSV esportato, inclusi i prodotti terminati. Conservalo per il recupero.",
    );
    return;
  }
  if (op === "import") {
    plan.prompt(
      { step: "import" },
      "📥 Allega come risposta un CSV esportato da Frifrigobot (massimo 100 KB / 100 confezioni).",
    );
    return;
  }
  if (
    op === "importconfirm" &&
    s?.step === "importconfirm" &&
    session.token === a
  ) {
    plan.expectedSession = a;
    plan.add(
      `INSERT OR IGNORE INTO products(id,${fields.join(",")},updated_at) SELECT json_extract(value,'$.id'),${fields.map((k) => (k === "track_opening" ? "coalesce(json_extract(value,'$.track_opening'),1)" : "json_extract(value,'$." + k + "')")).join(",")},? FROM json_each(?) WHERE {G}`,
      new Date().toISOString(),
      JSON.stringify(s.rows),
    );
    plan.clear();
    plan.send(
      "✅ Recupero completato. Gli ID già presenti sono stati ignorati.",
    );
    return;
  }
  if (op === "wiz") {
    plan.expectedSession = a;
    if (
      !session ||
      session.token !== a ||
      Date.now() - Date.parse(session.updated_at) > 3600000
    ) {
      plan.send("Questo pulsante non è più attivo. Ricomincia dal menu.");
      return;
    }
    if (
      b === "days" &&
      s.step === "days" &&
      /^\d+$/.test(c) &&
      +c >= 1 &&
      +c <= 365
    )
      askOriginal(plan, { ...s, after_days: +c, track_opening: 1 });
    else if (b === "noopening" && s.step === "days")
      askOriginal(plan, { ...s, after_days: 1, track_opening: 0 });
    else if (b === "customdays" && s.step === "days")
      plan.prompt(s, "Quanti giorni dopo l’apertura? Da 1 a 365.");
    else if (b === "original" && s.step === "original")
      review(plan, { ...s, original_date: null });
    else if (b === "customoriginal" && s.step === "original")
      plan.prompt(s, "Scrivi la data sulla confezione in formato GG/MM/AAAA.");
    else if (b === "count" && s.step === "review")
      plan.prompt(
        { ...s, step: "count" },
        "Quante confezioni uguali? Da 1 a 20. Ognuna avrà un’identità separata.",
      );
    else if (b === "category" && s.step === "review")
      plan.prompt(
        { ...s, step: "category" },
        "Categoria facoltativa (es. Latticini). Scrivi - per lasciarla vuota.",
      );
    else if (["save", "saveopen"].includes(b) && s.step === "review") {
      for (let i = 0; i < (s.count || 1); i++)
        plan.add(
          "INSERT INTO products(id,name,category,original_date,after_days,opened_date,quantity,updated_at,track_opening) SELECT ?,?,?,?,?,?,?,?,? WHERE {G}",
          uid(),
          s.name,
          s.category || "",
          s.original_date || null,
          s.after_days,
          b === "saveopen" && tracksOpening(s) ? rome().date : null,
          "1 confezione",
          new Date().toISOString(),
          s.track_opening ?? 1,
        );
      plan.add(
        "INSERT INTO templates(name_key,name,after_days,category,track_opening) SELECT ?,?,?,?,? WHERE {G} ON CONFLICT(name_key) DO UPDATE SET after_days=excluded.after_days,category=excluded.category,track_opening=excluded.track_opening",
        key(s.name),
        s.name,
        s.after_days,
        s.category || "",
        s.track_opening ?? 1,
      );
      plan.clear();
      plan.send(
        `✅ Aggiunte ${s.count || 1} confezioni di <b>${esc(s.name)}</b>${b === "saveopen" ? ", aperte oggi" : ""}.`,
        keys([
          [
            btn("🧊 Il mio frigo", "list:all:0"),
            btn("➕ Aggiungi altro", "add"),
          ],
        ]),
      );
    }
    return;
  }
  if (op === "undo") {
    const u = await one(plan.env.DB, "SELECT * FROM undo WHERE id=?", a);
    if (!u) {
      plan.send("Operazione non disponibile.");
      return;
    }
    const p = await one(
      plan.env.DB,
      "SELECT * FROM products WHERE id=?",
      u.product_id,
    );
    if (!p || p.version !== u.expected_version) {
      plan.send("Sono state fatte altre modifiche: correggi dai dettagli.");
      return;
    }
    await change(plan, p, JSON.parse(u.snapshot));
    return;
  }
  if (
    [
      "open",
      "date",
      "finish",
      "restore",
      "edit",
      "field",
      "noopening",
    ].includes(op)
  ) {
    const p = await one(plan.env.DB, "SELECT * FROM products WHERE id=?", a);
    if (!p || p.version !== +b) {
      plan.send(
        "Pulsante superato. Aggiorna i dettagli.",
        keys([[btn("Aggiorna", `item:${a}`)]]),
      );
      return;
    }
    if (
      (op === "open" ||
        op === "date" ||
        (op === "field" && c === "opened_date")) &&
      !tracksOpening(p)
    ) {
      plan.send("Questo prodotto usa solo la scadenza sulla confezione.");
      return;
    }
    if (op === "noopening" && !p.finished) {
      await change(plan, p, {
        track_opening: 0,
        opened_date: null,
        after_days: 1,
      });
      plan.add(
        "UPDATE templates SET track_opening=0,after_days=1 WHERE name_key=? AND {G}",
        key(p.name),
      );
    } else if (op === "open" && !p.finished && !p.opened_date)
      await change(plan, p, { opened_date: rome().date });
    else if (op === "finish" && !p.finished)
      await change(plan, p, { finished: 1 });
    else if (op === "restore" && p.finished)
      await change(plan, p, { finished: 0 });
    else if (op === "edit")
      plan.send(
        "✏️ Quale dato vuoi correggere?",
        keys(
          [
            ["Nome", "name"],
            ["Categoria", "category"],
            ["Scadenza confezione", "original_date"],
            ["Giorni dopo apertura", "after_days"],
            ["Data apertura / richiudi", "opened_date"],
            ["Quantità descrittiva", "quantity"],
          ]
            .filter(([, f]) => tracksOpening(p) || f !== "opened_date")
            .map(([label, f]) => [
              btn(label, `field:${p.id}:${p.version}:${f}`),
            ])
            .concat([
              [btn("📅 Solo scadenza", `noopening:${p.id}:${p.version}`)],
            ]),
        ),
      );
    else if (op === "date" || op === "field") {
      const field = op === "date" ? "opened_date" : c;
      if (
        !fields.includes(field) ||
        ["finished", "track_opening"].includes(field)
      )
        return;
      plan.prompt(
        { step: "editfield", id: p.id, version: p.version, field },
        ["opened_date", "original_date"].includes(field)
          ? "Scrivi la data in formato GG/MM/AAAA. Scrivi - per rimuoverla."
          : field === "after_days"
            ? "Quanti giorni dopo l’apertura? Da 1 a 365."
            : "Scrivi il nuovo valore.",
      );
    }
    return;
  }
}
export async function processUpdate(env, u) {
  const m = u.callback_query?.message || u.message,
    user = u.callback_query?.from || u.message?.from;
  if (!m || !user || user.is_bot || !Number.isSafeInteger(u.update_id)) return;
  if (
    !env.CHAT_ID ||
    String(m.chat.id) !== String(env.CHAT_ID) ||
    !["group", "supergroup"].includes(m.chat.type) ||
    !String(env.ALLOWED_USER_IDS || "")
      .split(",")
      .map((x) => x.trim())
      .includes(String(user.id))
  )
    return;
  if (await one(env.DB, "SELECT id FROM processed WHERE id=?", u.update_id)) {
    await flush(env);
    return;
  }
  const plan = new Plan(env, u.update_id, user.id);
  plan.messageId = m.message_id;
  const session = await one(
    env.DB,
    "SELECT * FROM sessions WHERE user_id=?",
    String(user.id),
  );
  if (u.callback_query) {
    try {
      await telegram(env, "answerCallbackQuery", {
        callback_query_id: u.callback_query.id,
      });
    } catch {}
    await callback(plan, u.callback_query.data || "", session);
  } else await handleText(plan, m, session);
  await plan.commit();
  await flush(env);
}
export async function scheduled(env, now = new Date()) {
  const r = rome(now),
    s = await one(env.DB, "SELECT * FROM settings WHERE id=1");
  if (!s || r.hour < s.hour) {
    await flush(env, now.getTime());
    return;
  }
  const ps = sorted(
    await all(env.DB, "SELECT * FROM products WHERE finished=0"),
    r.date,
  );
  let alerts = [];
  for (const p of ps) {
    const e = expiry(p);
    if (!e) continue;
    const d = daysBetween(r.date, e);
    if ((d === 1 && s.day_before) || (d === 0 && s.on_day))
      alerts.push(`• ${esc(packageLabel(p, ps))}: ${remaining(p, r.date)}`);
  }
  if (s.summary) {
    const checks = ps.filter((p) => group(p, r.date) <= 2);
    if (checks.length)
      alerts.push(
        "\n📋 Da controllare:\n" +
          checks
            .slice(0, 15)
            .map(
              (p) => `• ${esc(packageLabel(p, ps))}: ${remaining(p, r.date)}`,
            )
            .join("\n"),
      );
  }
  if (alerts.length) {
    const text =
      `⏰ <b>Frifrigobot · ${displayDate(r.date)}</b>\n` +
      alerts.slice(0, 15).join("\n");
    await env.DB.prepare(
      "INSERT OR IGNORE INTO outbox(id,payload,created_at) VALUES(?,?,?)",
    )
      .bind(
        "daily:" + r.date,
        JSON.stringify({
          method: "sendMessage",
          body: {
            chat_id: env.CHAT_ID,
            text,
            parse_mode: "HTML",
            reply_markup: home(),
          },
        }),
        now.toISOString(),
      )
      .run();
  }
  await flush(env, now.getTime());
  await env.DB.batch([
    env.DB.prepare(
      "DELETE FROM processed WHERE created_at < strftime('%Y-%m-%dT%H:%M:%fZ','now','-7 days')",
    ),
    env.DB.prepare(
      "DELETE FROM sessions WHERE updated_at < strftime('%Y-%m-%dT%H:%M:%fZ','now','-1 day')",
    ),
    env.DB.prepare(
      "DELETE FROM undo WHERE created_at < strftime('%Y-%m-%dT%H:%M:%fZ','now','-30 days')",
    ),
    env.DB.prepare(
      "DELETE FROM outbox WHERE status='sent' AND created_at < strftime('%Y-%m-%dT%H:%M:%fZ','now','-30 days')",
    ),
  ]);
}
export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === "/setup" || path === "/activate") {
      const response = await activation(request, env);
      if (response) return response;
    }
    if (path === "/health" && request.method === "GET")
      return new Response("Frifrigobot online · versione 1.1.0", {
        headers: { "Cache-Control": "no-store" },
      });
    if (path !== "/telegram" || request.method !== "POST")
      return new Response("Not found", { status: 404 });
    if (
      !env.WEBHOOK_SECRET ||
      request.headers.get("X-Telegram-Bot-Api-Secret-Token") !==
        env.WEBHOOK_SECRET
    )
      return new Response("Forbidden", { status: 403 });
    if (!env.CHAT_ID || !env.ALLOWED_USER_IDS || !env.BOT_TOKEN)
      return new Response("Not configured", { status: 503 });
    if (Number(request.headers.get("content-length") || 0) > 262144)
      return new Response("Too large", { status: 413 });
    try {
      const raw = await request.text();
      if (raw.length > 262144)
        return new Response("Too large", { status: 413 });
      await processUpdate(env, JSON.parse(raw));
      return new Response("OK");
    } catch {
      console.error("telegram_update_failed");
      return new Response("Retry later", { status: 500 });
    }
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil(scheduled(env, new Date(event.scheduledTime)));
  },
};
