const fmt = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Rome",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  hourCycle: "h23",
});
export function rome(now = new Date()) {
  const p = Object.fromEntries(
    fmt.formatToParts(now).map((x) => [x.type, x.value]),
  );
  return { date: `${p.year}-${p.month}-${p.day}`, hour: Number(p.hour) };
}
export function addDays(d, n) {
  const x = new Date(`${d}T12:00:00Z`);
  x.setUTCDate(x.getUTCDate() + n);
  return x.toISOString().slice(0, 10);
}
export function daysBetween(a, b) {
  return Math.round(
    (Date.parse(b + "T12:00:00Z") - Date.parse(a + "T12:00:00Z")) / 86400000,
  );
}
export function parseDate(s) {
  s = s.trim();
  let d;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) d = s;
  else {
    const m = s.match(/^(\d{1,2})[/.](\d{1,2})[/.](\d{4})$/);
    if (!m) return null;
    d = `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  }
  const dt = new Date(d + "T12:00:00Z");
  return !isNaN(dt) &&
    dt.toISOString().slice(0, 10) === d &&
    d >= "2000-01-01" &&
    d <= "2100-12-31"
    ? d
    : null;
}
export const displayDate = (d) =>
  d ? d.split("-").reverse().join("/") : "non indicata";
export const tracksOpening = (p) => p.track_opening !== 0;
export function expiry(p) {
  const a =
    tracksOpening(p) && p.opened_date
      ? addDays(p.opened_date, p.after_days)
      : null;
  return a && p.original_date
    ? a < p.original_date
      ? a
      : p.original_date
    : a || p.original_date || null;
}
export function group(p, today) {
  if (p.finished) return 5;
  const e = expiry(p),
    d = e ? daysBetween(today, e) : Infinity;
  return d < 0 ? 0 : d === 0 ? 1 : d <= 3 ? 2 : p.opened_date ? 3 : 4;
}
export const titles = [
  "🔴 Scaduti",
  "🟠 Da consumare oggi",
  "🟡 Entro 3 giorni",
  "🟢 Aperti",
  "🔵 Chiusi",
];
export function expiryTitle(p, today) {
  const e = expiry(p);
  if (!e) return "⚪ Senza scadenza indicata";
  const n = daysBetween(today, e);
  return n < 0
    ? "🔴 Scaduti"
    : n === 0
      ? "🟠 Da consumare oggi"
      : n === 1
        ? "🟡 Entro domani"
        : `🟢 Restano ${n} giorni`;
}
export function packageLabel(p, ps) {
  const same = ps.filter((x) => x.name === p.name);
  const suffix =
    same.length > 1
      ? ` · confezione ${same.findIndex((x) => x.id === p.id) + 1}`
      : "";
  return `${p.name}${suffix}`;
}
export function sorted(ps, today) {
  return [...ps].sort(
    (a, b) =>
      (expiry(a) || "9999").localeCompare(expiry(b) || "9999") ||
      a.name.localeCompare(b.name) ||
      a.id.localeCompare(b.id),
  );
}
export function remaining(p, today) {
  const e = expiry(p);
  if (!e) return "nessuna scadenza indicata";
  const n = daysBetween(today, e);
  return n < 0
    ? `scaduto da ${-n} giorni`
    : n === 0
      ? "entro oggi"
      : n === 1
        ? "entro domani"
        : `restano ${n} giorni`;
}
export function csv(ps) {
  const cols = [
    "id",
    "name",
    "category",
    "original_date",
    "after_days",
    "opened_date",
    "quantity",
    "finished",
    "track_opening",
  ];
  return (
    "\uFEFF" +
    [
      cols,
      ...ps.map((p) =>
        cols.map((k) => (k === "track_opening" ? (p[k] ?? 1) : (p[k] ?? ""))),
      ),
    ]
      .map((row) =>
        row.map((v) => '"' + String(v).replaceAll('"', '""') + '"').join(","),
      )
      .join("\r\n")
  );
}
export function readCSV(text) {
  text = text.replace(/^\uFEFF/, "");
  const rows = [];
  let row = [],
    s = "",
    q = false;
  for (let i = 0; i < text.length; i++) {
    let c = text[i];
    if (c === '"') {
      if (q && text[i + 1] === '"') {
        s += '"';
        i++;
      } else if (q || s === "") q = !q;
      else throw Error("CSV non valido");
    } else if (c === "," && !q) {
      row.push(s);
      s = "";
    } else if ((c === "\n" || c === "\r") && !q) {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(s);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      s = "";
    } else s += c;
  }
  if (q) throw Error("Virgolette CSV non chiuse");
  if (s || row.length) {
    row.push(s);
    rows.push(row);
  }
  const cols = rows.shift();
  const expected = [
    "id",
    "name",
    "category",
    "original_date",
    "after_days",
    "opened_date",
    "quantity",
    "finished",
  ];
  const legacy = cols?.join() === expected.join();
  if (
    !cols ||
    (!legacy && cols.join() !== [...expected, "track_opening"].join())
  )
    throw Error("Usa un CSV esportato da Frifrigobot");
  if (rows.length > 100)
    throw Error("Importa al massimo 100 confezioni per file");
  const ids = new Set();
  return rows.map((r) => {
    if (r.length !== cols.length) throw Error("Colonne CSV non valide");
    let p = Object.fromEntries(cols.map((k, i) => [k, r[i]]));
    if (
      !/^[\w-]{1,40}$/.test(p.id) ||
      ids.has(p.id) ||
      !p.name.trim() ||
      p.name.length > 80 ||
      p.category.length > 60 ||
      p.quantity.length > 60 ||
      !/^\d+$/.test(p.after_days) ||
      +p.after_days < 1 ||
      +p.after_days > 365 ||
      !["0", "1"].includes(p.finished)
    )
      throw Error("Valori CSV non validi");
    for (const k of ["original_date", "opened_date"]) {
      if (p[k] && !parseDate(p[k])) throw Error("Data CSV non valida");
      p[k] = p[k] || null;
    }
    if (p.opened_date && p.opened_date > rome().date)
      throw Error("Apertura futura non valida");
    const track_opening = legacy ? 1 : Number(p.track_opening);
    if (
      (!legacy && !["0", "1"].includes(p.track_opening)) ||
      (!track_opening && p.opened_date)
    )
      throw Error("Modalità apertura CSV non valida");
    ids.add(p.id);
    return {
      ...p,
      name: p.name.trim(),
      track_opening,
      after_days: +p.after_days,
      finished: +p.finished,
    };
  });
}
