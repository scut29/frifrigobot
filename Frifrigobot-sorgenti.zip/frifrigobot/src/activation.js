import { telegram, flush } from "./worker.js";
const page = (content, status = 200) =>
  new Response(
    `<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Attiva Frifrigobot</title><style>body{font:18px system-ui;max-width:540px;margin:8vh auto;padding:24px;background:#f2f8f5;color:#173d32}main{padding:28px;border-radius:20px;background:white}input,button{font:inherit;box-sizing:border-box;width:100%;padding:14px;margin-top:12px;border:1px solid #bdd4c9;border-radius:10px}button{background:#176b50;color:white;cursor:pointer}p{line-height:1.5}label{display:block}</style><main><h1>🧊 Frifrigobot</h1>${content}</main></html>`,
    {
      status,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "Referrer-Policy": "same-origin",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy":
          "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
      },
    },
  );
export async function activation(request, env) {
  const url = new URL(request.url);
  if (url.pathname === "/setup" && request.method === "GET")
    return page(
      '<p>Dopo aver impostato i quattro segreti in Cloudflare, attiva il collegamento con Telegram.</p><form method="post" action="/activate"><label for="secret">WEBHOOK_SECRET configurato in Cloudflare</label><input id="secret" name="secret" type="password" autocomplete="off" minlength="32" maxlength="256" required><button>Attiva il bot</button></form><p>Il segreto viene usato solo per questa richiesta e non viene inserito nell’indirizzo o salvato dal modulo.</p>',
    );
  if (url.pathname !== "/activate" || request.method !== "POST") return null;
  const origin = request.headers.get("origin");
  if (origin && origin !== url.origin)
    return new Response("Forbidden", { status: 403 });
  if (Number(request.headers.get("content-length") || 0) > 2048)
    return new Response("Too large", { status: 413 });
  const raw = await request.text();
  if (raw.length > 2048) return new Response("Too large", { status: 413 });
  const supplied = new URLSearchParams(raw).get("secret");
  if (!env.WEBHOOK_SECRET || supplied !== env.WEBHOOK_SECRET)
    return page(
      "<p>Segreto non corretto. Torna indietro e usa il valore WEBHOOK_SECRET del tuo Worker.</p>",
      403,
    );
  if (
    !/^[A-Za-z0-9_-]{32,256}$/.test(env.WEBHOOK_SECRET) ||
    !/^-\d+$/.test(env.CHAT_ID || "") ||
    !/^\d+,\s*\d+$/.test(env.ALLOWED_USER_IDS || "") ||
    new Set(env.ALLOWED_USER_IDS.split(",").map((x) => x.trim())).size !== 2 ||
    !env.BOT_TOKEN
  )
    return page(
      "<p>Completa i quattro segreti Cloudflare: token del bot, segreto casuale di almeno 32 caratteri, ID del gruppo e due ID utente distinti separati da virgola.</p>",
      503,
    );
  try {
    await env.DB.prepare("SELECT id FROM settings WHERE id=1").first();
    const me = await telegram(env, "getMe", {});
    if (me.username?.toLowerCase() !== "frifrigobot")
      return page(
        "<p>Il token non appartiene a @Frifrigobot. Controlla BOT_TOKEN.</p>",
        503,
      );
    const chat = await telegram(env, "getChat", { chat_id: env.CHAT_ID });
    if (!["group", "supergroup"].includes(chat.type))
      return page("<p>CHAT_ID deve indicare il vostro gruppo.</p>", 503);
    await telegram(env, "setWebhook", {
      url: new URL("/telegram", url).toString(),
      secret_token: env.WEBHOOK_SECRET,
      max_connections: 1,
      allowed_updates: ["message", "callback_query"],
      drop_pending_updates: false,
    });
    const info = await telegram(env, "getWebhookInfo", {});
    if (info.url !== new URL("/telegram", url).toString())
      throw Error("Webhook non confermato");
    await env.DB.prepare(
      "INSERT OR IGNORE INTO outbox(id,payload,created_at) VALUES(?,?,?)",
    )
      .bind(
        "setup:welcome",
        JSON.stringify({
          method: "sendMessage",
          body: {
            chat_id: env.CHAT_ID,
            text: "🧊 Frifrigobot è collegato. Premi il pulsante per aprire il menu.",
            reply_markup: {
              inline_keyboard: [
                [{ text: "🧊 Apri il nostro frigo", callback_data: "home" }],
              ],
            },
          },
        }),
        new Date().toISOString(),
      )
      .run();
    await flush(env);
    return page(
      "<h2>Collegamento attivato</h2><p>Apri il gruppo Telegram e premi il pulsante del menu. La verifica dei prodotti e delle notifiche reali va completata nel gruppo.</p>",
    );
  } catch {
    console.error("activation_failed");
    return page(
      "<p>Attivazione non completata. Controlla che il bot sia nel gruppo e che il database sia stato inizializzato. Puoi riprovare senza duplicare l’inventario.</p>",
      503,
    );
  }
}
