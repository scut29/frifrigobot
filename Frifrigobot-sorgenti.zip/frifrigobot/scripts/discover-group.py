"""Read setup messages only. Never print the bot token or credentials."""
import os, json, urllib.request, getpass, urllib.error
secret = os.environ.get('BOT_TOKEN') or getpass.getpass('Token Telegram (nascosto): ')
def api(method, data):
    req=urllib.request.Request('https://api.telegram.org/bot'+secret+'/'+method,data=json.dumps(data).encode(),headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=20) as r: return json.load(r)
    except urllib.error.HTTPError as e: raise SystemExit('Telegram ha restituito HTTP '+str(e.code)) from None
    except Exception: raise SystemExit('Connessione Telegram non disponibile') from None
if api('getWebhookInfo',{}).get('result',{}).get('url'):
    raise SystemExit('Webhook già attivo: non lo disattivo per leggere i messaggi.')
for update in api('getUpdates',{'timeout':0,'limit':100}).get('result',[]):
    m=update.get('message',{});chat=m.get('chat',{});user=m.get('from',{})
    if m.get('text','').split('@')[0]=='/start' and chat.get('type') in ['group','supergroup']:
        print(json.dumps({'gruppo_id':chat.get('id'),'nome_gruppo':chat.get('title'),'utente_id':user.get('id'),'nome_utente':user.get('first_name')},ensure_ascii=False))
