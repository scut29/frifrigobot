// BOT_TOKEN and WEBHOOK_SECRET must come from the protected environment.
const url = process.argv[2];
if (
  !url ||
  !url.startsWith("https://") ||
  !process.env.BOT_TOKEN ||
  !process.env.WEBHOOK_SECRET
) {
  console.error(
    "Servono URL HTTPS, BOT_TOKEN e WEBHOOK_SECRET nell’ambiente protetto.",
  );
  process.exit(1);
}
const base = new URL(url);
base.pathname = "/telegram";
base.search = "";
base.hash = "";
const api = async (method, body) => {
  try {
    const r = await fetch(
      `https://api.telegram.org/bot${process.env.BOT_TOKEN}/${method}`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(20000),
      },
    );
    const d = await r.json();
    if (!d.ok) throw Error("API " + d.error_code);
    return d.result;
  } catch {
    throw Error(
      "Operazione Telegram non riuscita; nessuna credenziale viene stampata.",
    );
  }
};
const health = new URL("/health", base);
const r = await fetch(health, { signal: AbortSignal.timeout(15000) });
if (!r.ok || !(await r.text()).includes("Frifrigobot online"))
  throw Error("Prima pubblica e verifica il Worker.");
await api("setWebhook", {
  url: base.toString(),
  secret_token: process.env.WEBHOOK_SECRET,
  max_connections: 1,
  allowed_updates: ["message", "callback_query"],
  drop_pending_updates: false,
});
const info = await api("getWebhookInfo", {});
console.log(
  JSON.stringify(
    {
      webhook_corretto: info.url === base.toString(),
      aggiornamenti_in_attesa: info.pending_update_count,
      errore: info.last_error_message || null,
    },
    null,
    2,
  ),
);
