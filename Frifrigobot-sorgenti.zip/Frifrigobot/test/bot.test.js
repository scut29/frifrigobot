import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import worker, { processUpdate, scheduled, flush } from "../src/worker.js";
import {
  rome,
  addDays,
  parseDate,
  expiry,
  group,
  csv,
  readCSV,
} from "../src/domain.js";
class D1 {
  constructor(path = ":memory:") {
    this.db = new DatabaseSync(path);
  }
  prepare(sql) {
    const db = this.db;
    let params = [];
    const obj = {
      bind(...p) {
        params = p;
        return obj;
      },
      async first() {
        return db.prepare(sql).get(...params) || null;
      },
      async all() {
        return { results: db.prepare(sql).all(...params) };
      },
      async run() {
        const s = db.prepare(sql);
        const results = s.columns().length
          ? s.all(...params)
          : (s.run(...params), []);
        return {
          results,
          meta: { changes: db.prepare("SELECT changes() n").get().n },
        };
      },
    };
    return obj;
  }
  async batch(ss) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const out = [];
      for (const s of ss) out.push(await s.run());
      this.db.exec("COMMIT");
      return out;
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    }
  }
}
function setup(path) {
  const DB = new D1(path);
  DB.db.exec(
    readFileSync(
      new URL("../migrations/0001_init.sql", import.meta.url),
      "utf8",
    ),
  );
  const sent = [];
  let mid = 500;
  const env = {
    DB,
    CHAT_ID: "-10055",
    ALLOWED_USER_IDS: "11,22",
    BOT_TOKEN: "test",
    WEBHOOK_SECRET: "test-secret",
    FETCH: async (url, options) => {
      const method = url.split("/").pop(),
        body = options.body instanceof FormData ? {} : JSON.parse(options.body);
      sent.push({ method, body });
      return Response.json({ ok: true, result: { message_id: ++mid } });
    },
  };
  let id = 0;
  const cb = (data, user = 11, chat = -10055, updateId) =>
    processUpdate(env, {
      update_id: updateId || ++id,
      callback_query: {
        id: "c" + id,
        from: { id: user },
        data,
        message: { message_id: 100, chat: { id: chat, type: "supergroup" } },
      },
    });
  const session = (user = 11) =>
    DB.db.prepare("SELECT * FROM sessions WHERE user_id=?").get(String(user));
  const text = (value, user = 11) =>
    processUpdate(env, {
      update_id: ++id,
      message: {
        message_id: 200 + id,
        from: { id: user },
        chat: { id: -10055, type: "supergroup" },
        text: value,
        reply_to_message: { message_id: session(user)?.prompt_id },
      },
    });
  const wiz = (action, user = 11) =>
    cb("wiz:" + session(user).token + ":" + action, user);
  return { env, DB, sent, cb, text, session, wiz };
}
async function add(h, name = "Latte", count = 1) {
  await h.cb("add");
  await h.text(name);
  const s = JSON.parse(h.session().data);
  if (s.after_days) await h.wiz("days:" + s.after_days);
  else await h.text("3");
  await h.wiz("original");
  if (count > 1) {
    await h.wiz("count");
    await h.text(String(count));
  }
  await h.wiz("save");
  return h.DB.db
    .prepare("SELECT * FROM products ORDER BY rowid DESC LIMIT 1")
    .get();
}
test("date italiane, anno bisestile e entrambi i cambi DST", () => {
  assert.deepEqual(rome(new Date("2026-01-01T07:00:00Z")), {
    date: "2026-01-01",
    hour: 8,
  });
  assert.equal(rome(new Date("2026-07-01T06:00:00Z")).hour, 8);
  assert.equal(rome(new Date("2026-03-29T06:00:00Z")).hour, 8);
  assert.equal(rome(new Date("2026-10-25T07:00:00Z")).hour, 8);
  assert.equal(addDays("2026-03-28", 3), "2026-03-31");
  assert.equal(parseDate("29/02/2026"), null);
  assert.equal(parseDate("29/02/2028"), "2028-02-29");
  assert.equal(parseDate("31/11/2026"), null);
});
test("scadenza minima e raggruppamento", () => {
  const p = {
    opened_date: "2026-11-16",
    after_days: 3,
    original_date: "2026-11-17",
  };
  assert.equal(expiry(p), "2026-11-17");
  assert.equal(group(p, "2026-11-18"), 0);
  assert.equal(group(p, "2026-11-17"), 1);
  assert.equal(expiry({ ...p, original_date: null }), "2026-11-19");
});
test("wizard, confezioni indipendenti, apertura, modifica, terminato e annullamento", async () => {
  const h = setup();
  let p = await add(h, "Latte", 2);
  assert.equal(h.DB.db.prepare("SELECT count(*) n FROM products").get().n, 2);
  await h.cb(`open:${p.id}:${p.version}`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.opened_date, rome().date);
  assert.equal(p.version, 2);
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM products WHERE opened_date IS NULL")
      .get().n,
    1,
  );
  await h.cb(`field:${p.id}:2:original_date`);
  await h.text("01/01/2026");
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(expiry(p), "2026-01-01");
  await h.cb(`finish:${p.id}:${p.version}`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.finished, 1);
  const last = h.sent.filter((x) => x.method === "sendMessage").at(-1).body;
  await h.cb(last.reply_markup.inline_keyboard[0][0].callback_data);
  assert.equal(
    h.DB.db.prepare("SELECT finished FROM products WHERE id=?").get(p.id)
      .finished,
    0,
  );
  await h.cb("list:all:0", 22);
  assert.match(h.sent.at(-1).body.text, /Latte/);
});
test("durata ricordata e procedure separate per utente", async () => {
  const h = setup();
  await add(h);
  await h.cb("add");
  await h.text("latte");
  assert.match(h.sent.at(-1).body.text, /3 giorni/);
  const token = h.session().token;
  await h.cb("add", 22);
  await h.text("Yogurt", 22);
  assert.equal(h.session().token, token);
  assert.equal(JSON.parse(h.session(22).data).name, "Yogurt");
});
test("duplicati webhook e pulsanti superati", async () => {
  const h = setup();
  let p = await add(h);
  await h.cb(`open:${p.id}:1`, 11, -10055, 5000);
  await h.cb(`open:${p.id}:1`, 11, -10055, 5000);
  await h.cb(`finish:${p.id}:1`);
  p = h.DB.db.prepare("SELECT * FROM products WHERE id=?").get(p.id);
  assert.equal(p.version, 2);
  assert.equal(p.finished, 0);
  assert.match(h.sent.at(-1).body.text, /superato/);
});
test("autorizzazioni gruppo, utenti e segreto webhook", async () => {
  const h = setup();
  await h.cb("add", 99);
  await h.cb("add", 11, -999);
  assert.equal(h.sent.length, 0);
  assert.equal(
    (
      await worker.fetch(
        new Request("https://bot/telegram", { method: "POST", body: "{}" }),
        h.env,
      )
    ).status,
    403,
  );
  assert.equal(
    (await worker.fetch(new Request("https://bot/health"), h.env)).status,
    200,
  );
});
test("notifica alle 8 italiane, deduplica e notifica prova", async () => {
  const h = setup();
  await add(h);
  h.DB.db.prepare("UPDATE products SET original_date=?").run("2026-11-17");
  h.sent.length = 0;
  await scheduled(h.env, new Date("2026-11-16T06:45:00Z"));
  assert.equal(h.sent.length, 0);
  await scheduled(h.env, new Date("2026-11-16T07:00:00Z"));
  assert.equal(h.sent.length, 1);
  await scheduled(h.env, new Date("2026-11-16T07:15:00Z"));
  assert.equal(h.sent.length, 1);
  await scheduled(h.env, new Date("2026-11-17T07:00:00Z"));
  assert.equal(h.sent.length, 2);
  await h.cb("testnotify");
  assert.match(h.sent.at(-1).body.text, /Notifica di prova/);
});
test("coda persistente e retry dopo errore Telegram", async () => {
  const h = setup(),
    original = h.env.FETCH;
  h.env.FETCH = async () =>
    Response.json(
      { ok: false, error_code: 429, parameters: { retry_after: 1 } },
      { status: 429 },
    );
  await h.cb("home");
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    1,
  );
  h.env.FETCH = original;
  await flush(h.env, Date.now() + 120000);
  assert.equal(
    h.DB.db
      .prepare("SELECT count(*) n FROM outbox WHERE status='pending'")
      .get().n,
    0,
  );
});
test("persistenza dopo chiusura e riapertura database su disco", async () => {
  const dir = mkdtempSync(join(tmpdir(), "frifrigobot-")),
    path = join(dir, "db.sqlite");
  const h = setup(path),
    p = await add(h);
  h.DB.db.close();
  const db = new D1(path);
  assert.equal(
    (
      await db
        .prepare("SELECT name FROM products WHERE id=?")
        .bind(p.id)
        .first()
    ).name,
    "Latte",
  );
  db.db.close();
  rmSync(dir, { recursive: true });
});
test("CSV completo: virgole, virgolette, righe multiple e validazione", () => {
  const p = {
    id: "abc",
    name: 'Latte, "bio"\nintero',
    category: "Latticini",
    original_date: null,
    after_days: 3,
    opened_date: null,
    quantity: "1",
    finished: 0,
  };
  assert.deepEqual(readCSV(csv([p]))[0], p);
  assert.throws(() => readCSV("evil\n1"));
  assert.throws(() => readCSV(csv([{ ...p, after_days: 0 }])));
});
test("rollback atomico D1 batch", async () => {
  const h = setup();
  await assert.rejects(() =>
    h.DB.batch([
      h.DB.prepare("UPDATE settings SET hour=10 WHERE id=1"),
      h.DB.prepare("INSERT INTO missing VALUES(1)"),
    ]),
  );
  assert.equal(h.DB.db.prepare("SELECT hour FROM settings").get().hour, 8);
});

test("attivazione protetta: origine, segreto, webhook e benvenuto unico", async () => {
  const h = setup();
  h.env.WEBHOOK_SECRET = "a".repeat(64);
  let target = null,
    welcome = 0;
  h.env.FETCH = async (url, opts) => {
    const method = url.split("/").pop(),
      body = JSON.parse(opts.body);
    let result = {};
    if (method === "getMe") result = { username: "Frifrigobot" };
    if (method === "getChat") result = { type: "supergroup" };
    if (method === "setWebhook") {
      target = body.url;
      result = true;
    }
    if (method === "getWebhookInfo") result = { url: target };
    if (method === "sendMessage") {
      welcome++;
      result = { message_id: 101 };
    }
    return Response.json({ ok: true, result });
  };
  const page = await worker.fetch(new Request("https://bot/setup"), h.env);
  assert.equal(page.status, 200);
  assert.ok(!(await page.text()).includes(h.env.WEBHOOK_SECRET));
  const activate = (secret, origin = "https://bot") =>
    worker.fetch(
      new Request("https://bot/activate", {
        method: "POST",
        headers: {
          Origin: origin,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ secret }),
      }),
      h.env,
    );
  assert.equal((await activate("wrong")).status, 403);
  assert.equal(
    (await activate(h.env.WEBHOOK_SECRET, "https://elsewhere")).status,
    403,
  );
  assert.equal((await activate(h.env.WEBHOOK_SECRET)).status, 200);
  assert.equal(target, "https://bot/telegram");
  assert.equal(welcome, 1);
  await activate(h.env.WEBHOOK_SECRET);
  assert.equal(welcome, 1);
});
